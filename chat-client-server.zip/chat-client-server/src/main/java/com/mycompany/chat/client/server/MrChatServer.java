/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.chat.client.server;

import java.io.IOException;
import java.net.*;

/**
 *
 * @author Bucci
 */
public class MrChatServer extends Thread{
    private int port;
    private ServerSocket server;
    private ChannelsManager manager;

    public MrChatServer(int port, ChannelsManager manager) throws IOException {
      this.port = port;
      this.manager = manager;
      server = new ServerSocket(port);
    }

    public MrChatServer(int port) throws IOException {
      this(port, new ChannelsManager());
    }

    public int getPort() {
      return port;
    }

    public void run() {
      try {
        while(true) {
          Socket socket = server.accept();//Chiamata bloccante
          manager.initialite(socket);
        }
      } catch(Exception ex) {
          ex.printStackTrace();
      }
    }
}
