/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.chat.client.server;

import java.io.IOException;

/**
 *
 * @author Bucci
 */
public class clientmain {

    public static void main(String[] args) throws IOException{
        ChannelsManager manager = new ChannelsManager();
        DefaultMrChatProtocol protocol = new DefaultMrChatProtocol(manager);
        MrChatServer server = new MrChatServer(10000, manager);
        server.start();
    }

}
