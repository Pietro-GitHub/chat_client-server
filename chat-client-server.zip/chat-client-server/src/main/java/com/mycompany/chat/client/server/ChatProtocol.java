/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.chat.client.server;

/**
 *
 * @author Bucci
 */
public abstract class ChatProtocol {
    protected ChannelsManager manager;
    public ChatProtocol(ChannelsManager manager) {
      this.manager = manager;
      manager.setChatProtocol(this);
    }
    public abstract void startMessage(ThreadChannel ch);
    public abstract void parserMessage(ThreadChannel channel, String msg);
}
